"""
Logo rest python library.
"""

__version__ = "0.0.5"

from .service import LogoService
