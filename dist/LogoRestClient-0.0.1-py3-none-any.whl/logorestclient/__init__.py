"""
Logo rest python library.
"""

__version__ = "0.1.0"

from .service import LogoService
