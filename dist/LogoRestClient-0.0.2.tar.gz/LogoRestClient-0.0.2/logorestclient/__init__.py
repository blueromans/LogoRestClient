"""
Logo rest python library.
"""

__version__ = "0.0.2"

from .service import LogoService
