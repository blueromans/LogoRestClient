"""
Logo rest python library.
"""

__version__ = "0.0.3"

from .service import LogoService
